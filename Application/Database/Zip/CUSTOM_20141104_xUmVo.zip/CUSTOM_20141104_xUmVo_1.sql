# -----------------------------------------------------------
# PHP-Amateur database backup files
# Blog: http://blog.51edm.org
# Type: 管理员后台手动备份
# Description:当前SQL文件包含了表：jkd_ad、jkd_admin、jkd_category、jkd_field、jkd_images、jkd_input、jkd_link、jkd_member、jkd_member_address、jkd_message、jkd_model、jkd_nav、jkd_news、jkd_node、jkd_page、jkd_product、jkd_product_ask、jkd_product_cart、jkd_product_collect、jkd_product_comment、jkd_product_order、jkd_role、jkd_role_user、jkd_tag的结构信息，表：jkd_ad、jkd_admin、jkd_category、jkd_field、jkd_images、jkd_input、jkd_link、jkd_member、jkd_member_address、jkd_message、jkd_model、jkd_nav、jkd_news、jkd_node、jkd_page、jkd_product、jkd_product_ask、jkd_product_cart、jkd_product_collect、jkd_product_comment、jkd_product_order、jkd_role、jkd_role_user、jkd_tag的数据
# Time: 2014-11-04 15:25:33
# -----------------------------------------------------------
# 当前SQL卷标：#1
# -----------------------------------------------------------


# 数据库表：jkd_ad 结构信息
DROP TABLE IF EXISTS `jkd_ad`;
CREATE TABLE `jkd_ad` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `ad_name` varchar(60) NOT NULL DEFAULT '',
  `ad_link` varchar(255) NOT NULL DEFAULT '',
  `ad_img` varchar(255) NOT NULL,
  `position` char(10) NOT NULL DEFAULT '0',
  `sort` tinyint(1) unsigned NOT NULL DEFAULT '50',
  `lang` varchar(10) NOT NULL DEFAULT 'zh-cn',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_admin 结构信息
DROP TABLE IF EXISTS `jkd_admin`;
CREATE TABLE `jkd_admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL COMMENT '登录账号',
  `pwd` char(32) DEFAULT NULL COMMENT '登录密码',
  `status` int(11) DEFAULT '1' COMMENT '账号状态',
  `remark` varchar(255) DEFAULT '' COMMENT '备注信息',
  `find_code` char(5) DEFAULT NULL COMMENT '找回账号验证码',
  `time` int(10) DEFAULT NULL COMMENT '开通时间',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='网站后台管理员表' ;

# 数据库表：jkd_category 结构信息
DROP TABLE IF EXISTS `jkd_category`;
CREATE TABLE `jkd_category` (
  `cid` int(5) NOT NULL AUTO_INCREMENT,
  `pid` int(5) DEFAULT NULL COMMENT 'parentCategory上级分类',
  `name` varchar(20) DEFAULT NULL COMMENT '分类名称',
  `type` varchar(10) NOT NULL DEFAULT 'n',
  `lang` varchar(10) NOT NULL DEFAULT 'zh-cn',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻分类表' ;

# 数据库表：jkd_field 结构信息
DROP TABLE IF EXISTS `jkd_field`;
CREATE TABLE `jkd_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `model_id` int(11) NOT NULL COMMENT '所属模型id',
  `name` varchar(128) NOT NULL COMMENT '字段名称',
  `comment` varchar(32) NOT NULL COMMENT '字段注释',
  `type` varchar(32) NOT NULL COMMENT '字段类型',
  `length` varchar(16) NOT NULL COMMENT '字段长度',
  `value` varchar(128) NOT NULL COMMENT '字段默认值',
  `is_require` tinyint(4) DEFAULT '0' COMMENT '是否必需',
  `is_unique` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否唯一',
  `is_index` tinyint(4) DEFAULT '0' COMMENT '是否添加索引',
  `is_system` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否系统字段',
  `is_list_show` tinyint(4) NOT NULL DEFAULT '1' COMMENT '列表中显示',
  `auto_filter` varchar(32) NOT NULL COMMENT '自动过滤函数',
  `auto_fill` varchar(32) NOT NULL COMMENT '自动完成函数',
  `fill_time` varchar(16) NOT NULL DEFAULT 'both' COMMENT '填充时机',
  `relation_model` int(11) NOT NULL COMMENT '关联的模型',
  `relation_field` varchar(128) NOT NULL COMMENT '关联的字段',
  `relation_value` varchar(128) NOT NULL COMMENT '关联显示的值',
  `created_at` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated_at` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `fk_field_model` (`model_id`),
  CONSTRAINT `jkd_field_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `jkd_model` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据模型字段' ;

# 数据库表：jkd_images 结构信息
DROP TABLE IF EXISTS `jkd_images`;
CREATE TABLE `jkd_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catname` varchar(20) NOT NULL,
  `savename` varchar(100) NOT NULL,
  `savepath` varchar(255) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_input 结构信息
DROP TABLE IF EXISTS `jkd_input`;
CREATE TABLE `jkd_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `field_id` int(11) NOT NULL COMMENT '字段id',
  `is_show` tinyint(4) NOT NULL DEFAULT '0' COMMENT '表单域是否显示',
  `label` varchar(32) NOT NULL COMMENT '表单域标签',
  `remark` varchar(128) NOT NULL COMMENT '表单域域',
  `type` varchar(32) NOT NULL COMMENT '表单域类型',
  `width` int(11) NOT NULL DEFAULT '20' COMMENT '表单域宽度',
  `height` int(11) NOT NULL DEFAULT '8' COMMENT '表单域高度',
  `opt_value` text NOT NULL COMMENT '表单域可选值',
  `value` varchar(128) NOT NULL COMMENT '表单域默认值',
  `editor` varchar(32) NOT NULL COMMENT '编辑器类型',
  `html` text NOT NULL COMMENT '表单域html替换',
  `show_order` int(11) DEFAULT NULL COMMENT '表单域显示顺序',
  `created_at` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated_at` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `fk_field_input` (`field_id`),
  CONSTRAINT `jkd_input_ibfk_1` FOREIGN KEY (`field_id`) REFERENCES `jkd_field` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='字段表单域信息' ;

# 数据库表：jkd_link 结构信息
DROP TABLE IF EXISTS `jkd_link`;
CREATE TABLE `jkd_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL,
  `display` int(1) NOT NULL,
  `link` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL,
  `target` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_member 结构信息
DROP TABLE IF EXISTS `jkd_member`;
CREATE TABLE `jkd_member` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(5) DEFAULT NULL COMMENT '真实姓名',
  `tencent_uid` varchar(20) DEFAULT NULL COMMENT '腾讯微博UID',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱地址',
  `nickname` varchar(20) DEFAULT NULL COMMENT '用户昵称',
  `pwd` char(32) DEFAULT NULL COMMENT '密码',
  `reg_date` int(10) DEFAULT NULL,
  `reg_ip` char(15) DEFAULT NULL COMMENT '注册IP地址',
  `birthday_year` int(4) DEFAULT NULL COMMENT '生日年份',
  `birthday_month` int(2) DEFAULT NULL COMMENT '生日月份',
  `birthday_day` int(2) DEFAULT NULL COMMENT '生日日期',
  `set_pass_time` int(12) DEFAULT NULL COMMENT '密码修改时间',
  `pay_pass` varchar(32) DEFAULT NULL COMMENT '支付密码',
  `avatar_old` varchar(255) DEFAULT NULL COMMENT '头像原图',
  `avatar_32` varchar(255) DEFAULT NULL COMMENT '头像32*32',
  `marriage` int(1) DEFAULT NULL COMMENT '用户婚姻状态0，未。1，已。2，保密',
  `edu` int(1) DEFAULT NULL COMMENT '教育程度',
  `sex` int(1) DEFAULT NULL COMMENT '0女1男',
  `address` varchar(50) DEFAULT NULL COMMENT '地址',
  `industry` int(1) DEFAULT NULL COMMENT '所属行业',
  `income` int(1) DEFAULT NULL COMMENT '月均收入',
  `jiu` varchar(255) DEFAULT NULL COMMENT '个人介绍',
  `jiu_brand` text COMMENT '酒的品牌',
  `phone` int(12) DEFAULT NULL COMMENT '电话',
  `fax` varchar(30) DEFAULT NULL,
  `qq` int(15) DEFAULT NULL,
  `msn` varchar(100) DEFAULT NULL,
  `login_ip` varchar(15) DEFAULT NULL COMMENT '登录ip',
  `login_time` int(10) DEFAULT NULL COMMENT '登录时间',
  `last_login_time` int(12) DEFAULT NULL,
  `last_login_ip` varchar(16) DEFAULT NULL,
  `avatar_50` varchar(255) DEFAULT NULL COMMENT '头像50*50',
  `avatar_100` varchar(255) DEFAULT NULL COMMENT '头像100*100',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='网站前台会员表' ;

# 数据库表：jkd_member_address 结构信息
DROP TABLE IF EXISTS `jkd_member_address`;
CREATE TABLE `jkd_member_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shen_cityname` varchar(50) DEFAULT NULL,
  `shi_cityname` varchar(50) DEFAULT NULL,
  `xian_cityname` varchar(50) DEFAULT NULL,
  `postcode` char(6) DEFAULT NULL,
  `address` text,
  `username` varchar(50) DEFAULT NULL,
  `phone` char(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_message 结构信息
DROP TABLE IF EXISTS `jkd_message`;
CREATE TABLE `jkd_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `email` varchar(32) NOT NULL,
  `moblie` char(15) NOT NULL,
  `display` int(1) NOT NULL DEFAULT '0',
  `addtime` int(11) NOT NULL,
  `content` text NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_model 结构信息
DROP TABLE IF EXISTS `jkd_model`;
CREATE TABLE `jkd_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(32) NOT NULL COMMENT '模型名称',
  `tbl_name` varchar(32) NOT NULL COMMENT '数据表名称',
  `menu_name` varchar(32) NOT NULL COMMENT '菜单名称',
  `is_inner` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为内部表',
  `has_pk` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否包含主键',
  `tbl_engine` varchar(16) NOT NULL DEFAULT 'InnoDB' COMMENT '引擎类型',
  `description` text NOT NULL COMMENT '模型描述',
  `created_at` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated_at` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='数据模型信息' ;

# 数据库表：jkd_nav 结构信息
DROP TABLE IF EXISTS `jkd_nav`;
CREATE TABLE `jkd_nav` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(20) NOT NULL,
  `nav_name` varchar(255) NOT NULL,
  `parent_id` smallint(5) NOT NULL DEFAULT '0',
  `guide` int(11) NOT NULL,
  `type` varchar(10) NOT NULL,
  `link` varchar(225) NOT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'zh-cn' COMMENT '语言',
  `sort` tinyint(1) unsigned NOT NULL DEFAULT '50',
  `tag` varchar(50) DEFAULT NULL,
  `target` int(1) NOT NULL DEFAULT '0',
  `keywords` varchar(255) NOT NULL,
  `description` text,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`keywords`),
  UNIQUE KEY `tag` (`tag`),
  UNIQUE KEY `tag_2` (`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_news 结构信息
DROP TABLE IF EXISTS `jkd_news`;
CREATE TABLE `jkd_news` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `kuozhan` text,
  `cid` smallint(3) DEFAULT NULL COMMENT '所在分类',
  `title` varchar(200) DEFAULT NULL COMMENT '新闻标题',
  `keywords` varchar(50) DEFAULT NULL COMMENT '文章关键字',
  `description` mediumtext COMMENT '文章描述',
  `status` tinyint(1) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL COMMENT '文章摘要',
  `published` int(10) DEFAULT NULL,
  `update_time` int(10) DEFAULT NULL,
  `content` text,
  `click` int(11) NOT NULL DEFAULT '0',
  `aid` smallint(3) DEFAULT NULL COMMENT '发布者UID',
  `is_recommend` int(1) NOT NULL DEFAULT '0',
  `image_id` varchar(100) NOT NULL DEFAULT '0',
  `lang` varchar(5) NOT NULL DEFAULT 'zh-cn',
  `bieming` varchar(255) NOT NULL,
  `gsname` varchar(100) DEFAULT NULL,
  `days` varchar(10) DEFAULT NULL,
  `kcaddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `rzsj` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='新闻表' ;

# 数据库表：jkd_node 结构信息
DROP TABLE IF EXISTS `jkd_node`;
CREATE TABLE `jkd_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COMMENT='权限节点表' ;

# 数据库表：jkd_page 结构信息
DROP TABLE IF EXISTS `jkd_page`;
CREATE TABLE `jkd_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(30) NOT NULL DEFAULT '',
  `parent_id` smallint(5) NOT NULL DEFAULT '0',
  `page_name` varchar(150) NOT NULL DEFAULT '',
  `content` longtext NOT NULL,
  `display` int(1) NOT NULL DEFAULT '0',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `lang` varchar(10) NOT NULL DEFAULT 'zh-cn',
  `image_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_product 结构信息
DROP TABLE IF EXISTS `jkd_product`;
CREATE TABLE `jkd_product` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `mold_id` int(10) DEFAULT NULL COMMENT '属性ID',
  `tuixiao` varchar(100) DEFAULT NULL COMMENT '品牌ID',
  `cid` int(10) DEFAULT NULL COMMENT '商品规格',
  `title` varchar(200) DEFAULT NULL COMMENT '产品标题',
  `price` double(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `image_id` varchar(255) NOT NULL COMMENT '图片',
  `keywords` varchar(50) DEFAULT NULL COMMENT '产品关键字',
  `description` mediumtext COMMENT '产品描述',
  `status` tinyint(1) DEFAULT NULL COMMENT '产品状态',
  `summary` text COMMENT '产品摘要',
  `published` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) DEFAULT NULL COMMENT '更新时间',
  `content` text,
  `lang` varchar(10) NOT NULL DEFAULT 'zh-cn',
  `aid` smallint(3) DEFAULT NULL COMMENT '购买次数',
  `click` int(11) NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `is_recommend` int(1) NOT NULL DEFAULT '0',
  `wap_display` int(1) NOT NULL DEFAULT '0',
  `auction` tinyint(2) DEFAULT NULL COMMENT '是否拍卖',
  `groupon` tinyint(2) DEFAULT NULL COMMENT '是否团购',
  `sale` tinyint(2) DEFAULT NULL COMMENT '是否秒杀',
  `credit` int(5) DEFAULT NULL COMMENT '积分',
  `market` double(10,2) DEFAULT NULL COMMENT '市场价',
  `number` varchar(100) DEFAULT NULL COMMENT '商品编号',
  `mold_pid` varchar(100) DEFAULT '0' COMMENT '属性pid',
  `mold_cid` varchar(100) DEFAULT '0' COMMENT '属性cid',
  `stock` int(11) DEFAULT '0' COMMENT '商品库存',
  `present` varchar(255) DEFAULT NULL COMMENT '赠品',
  `buy_num` int(11) DEFAULT '0' COMMENT '购买人数',
  PRIMARY KEY (`id`,`price`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='产品表' ;

# 数据库表：jkd_product_ask 结构信息
DROP TABLE IF EXISTS `jkd_product_ask`;
CREATE TABLE `jkd_product_ask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(50) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `mold_name` varchar(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `published` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `ask_content` text NOT NULL COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_product_cart 结构信息
DROP TABLE IF EXISTS `jkd_product_cart`;
CREATE TABLE `jkd_product_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` double(12,2) NOT NULL DEFAULT '0.00',
  `num` int(3) NOT NULL DEFAULT '0',
  `credit` int(15) NOT NULL DEFAULT '0',
  `uid` int(11) DEFAULT NULL,
  `pro_id` int(11) DEFAULT NULL,
  `published` int(11) NOT NULL DEFAULT '0',
  `present` varchar(255) DEFAULT NULL COMMENT '赠品',
  `market` double(11,2) DEFAULT '0.00' COMMENT '市场价',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_product_collect 结构信息
DROP TABLE IF EXISTS `jkd_product_collect`;
CREATE TABLE `jkd_product_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `published` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_product_comment 结构信息
DROP TABLE IF EXISTS `jkd_product_comment`;
CREATE TABLE `jkd_product_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `published` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `feel` tinyint(4) NOT NULL DEFAULT '5',
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_product_order 结构信息
DROP TABLE IF EXISTS `jkd_product_order`;
CREATE TABLE `jkd_product_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oid` char(20) NOT NULL,
  `uid` int(11) NOT NULL,
  `pro_id` varchar(255) NOT NULL,
  `aid` int(11) NOT NULL,
  `delivery` varchar(30) NOT NULL,
  `invoice` varchar(30) NOT NULL,
  `total_money` double(10,2) NOT NULL DEFAULT '0.00',
  `total_credit` int(15) NOT NULL DEFAULT '0',
  `present` text NOT NULL,
  `freight` int(11) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `content` text,
  `order_ip` char(16) NOT NULL,
  `published` int(11) NOT NULL DEFAULT '0',
  `update_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `oid` (`oid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ;

# 数据库表：jkd_role 结构信息
DROP TABLE IF EXISTS `jkd_role`;
CREATE TABLE `jkd_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='权限角色表' ;

# 数据库表：jkd_role_user 结构信息
DROP TABLE IF EXISTS `jkd_role_user`;
CREATE TABLE `jkd_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户角色表' ;

# 数据库表：jkd_tag 结构信息
DROP TABLE IF EXISTS `jkd_tag`;
CREATE TABLE `jkd_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  `unique_id` char(20) NOT NULL,
  `content` text NOT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'zh-cn',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;



# 数据库表：jkd_ad 数据信息


# 数据库表：jkd_admin 数据信息
INSERT INTO `jkd_admin` VALUES ('1','超级管理员','admin@qq.com','e5e4ad197497fc75565982791b425b51','1','我是超级管理员 哈哈~~','','1408686625');


# 数据库表：jkd_category 数据信息
INSERT INTO `jkd_category` VALUES ('1','0','白酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('2','1','价格','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('3','0','单瓶','product','zh-cn');
INSERT INTO `jkd_category` VALUES ('4','0','整箱','product','zh-cn');
INSERT INTO `jkd_category` VALUES ('5','0','礼盒','product','zh-cn');
INSERT INTO `jkd_category` VALUES ('6','0','小酒','product','zh-cn');
INSERT INTO `jkd_category` VALUES ('7','0','名酒经典套装','product','zh-cn');
INSERT INTO `jkd_category` VALUES ('8','0','酒具/酒盒','product','zh-cn');
INSERT INTO `jkd_category` VALUES ('9','0','五粮液','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('10','0','泸州老窖','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('11','0','口子窖','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('12','0','红星','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('13','0','牛栏山','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('14','0','郎酒','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('15','0','剑南春','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('16','0','洋河','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('17','0','国窖','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('18','0','水井坊','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('19','0','茅台','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('20','0','张裕','brand','zh-cn');
INSERT INTO `jkd_category` VALUES ('21','2','0-299','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('22','2','300-599','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('23','0','黄酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('24','0','红酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('25','0','洋酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('26','0','其他酒类','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('27','2','600-999','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('28','2','1000-1799','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('29','2','1800-3299','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('30','2','3300-6099','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('31','2','6100以上','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('32','1','度数','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('33','32','35度以下','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('34','32','35-39度','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('35','32','40-49度','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('36','32','50度以上','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('37','1','香型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('38','37','浓香型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('39','37','酱香型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('40','37','兼香型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('41','37','清香型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('42','37','芬香型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('43','37','绵柔型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('44','1','产地','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('45','44','江苏','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('46','44','南京','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('47','44','贵州','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('48','44','甘肃','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('49','1','促销','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('50','49','包邮','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('51','49','打折','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('52','49','送积分','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('53','49','送赠品','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('54','1','品牌','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('55','54','五粮液','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('56','54','茅台','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('57','54','郎酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('58','54','汾酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('60','23','品牌','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('61','60','古越龙山','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('62','60','女儿红','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('63','60','会稽山','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('64','60','唐宋','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('65','60','石库门','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('66','60','沙洲优黄','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('67','60','塔牌','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('68','60','咸亨','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('69','60','和酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('70','60','乌毡帽','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('71','60','师爷','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('72','60','吴越稽山','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('73','60','即墨老酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('94','23','省份','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('75','60','柳宗元','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('76','23','价格','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('77','76','0-69','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('78','76','70-199','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('79','76','200-399','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('80','76','400-699','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('81','76','700-1999','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('82','76','2000以上','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('84','23','度数','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('85','84','35度以下','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('86','84','35-39度','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('87','84','40-49度','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('88','84','50度以上','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('89','23','香型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('90','89','浓香','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('91','89','清香','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('92','89','兼香','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('93','89','其他','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('95','94','四川','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('96','94','江苏','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('97','94','北京','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('98','94','山西','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('99','94','湖北','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('100','94','其他','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('101','24','品牌','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('102','101','拉菲','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('103','101','张裕','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('104','101','长城','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('105','101','OHED','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('106','101','麦洛威尔','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('107','101','康纳斯顿','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('108','101','品尚红酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('109','101','名庄靓年','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('110','101','奔富','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('111','101','干露','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('112','24','价格','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('113','112','0-299','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('114','112','300-599','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('115','112','600-999','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('116','112','1000-1799','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('117','112','1800-3999','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('118','112','4000-5699','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('119','112','5700以上','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('120','24','原产地','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('121','120','中国','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('122','120','法国','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('123','120','意大利','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('124','120','西班牙','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('125','120','德国','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('126','120','澳大利亚','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('127','120','美国','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('128','120','南非','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('129','120','新西兰','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('130','120','阿根廷','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('131','120','加拿大','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('132','120','葡萄牙','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('133','120','其他','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('134','24','类型','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('135','134','红葡萄酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('136','134','白葡萄酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('137','134','桃红葡萄','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('138','134','酒香槟/起泡酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('139','134','冰酒/贵腐/甜酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('140','134','果酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('141','134','其他','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('142','24','葡萄品种','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('143','142','赤霞珠','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('144','142','梅洛','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('145','142','黑皮诺','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('146','142','西拉/设拉子','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('147','142','内比奥罗','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('148','142','桑娇维塞','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('149','142','佳美娜','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('150','142','仙粉黛','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('151','142','品乐珠','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('152','142','马尔贝克','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('153','142','霞多丽','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('154','142','长相思','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('155','25','品牌','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('156','155','轩尼诗','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('157','155','芝华士','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('158','155','百加得','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('159','155','杰克丹尼','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('160','155','尊尼获加','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('161','155','人头马','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('162','155','百龄坛','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('163','155','绝对伏特加','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('164','155','百利','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('165','155','马爹利','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('166','155','皇家礼炮','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('167','155','深蓝','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('168','155','锐澳','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('169','155','马天尼','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('170','155','真露','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('171','25','价格','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('172','171','0-199','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('173','171','200-399','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('174','171','400-799','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('175','171','800-1499','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('176','171','1500-3499','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('177','171','3500-5599','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('178','171','5600以上','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('179','25','国别','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('180','179','法国','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('181','179','英国','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('182','179','美国','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('183','179','俄罗斯','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('184','179','瑞典','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('185','179','荷兰','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('186','179','墨西哥','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('187','179','古巴','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('188','179','意大利','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('189','179','其他','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('190','25','类别','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('191','190','白兰地','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('192','190','威士忌','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('193','190','伏特加','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('194','190','金酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('195','190','龙舌兰','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('196','190','朗姆酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('197','190','力娇酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('198','190','鸡尾预调酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('199','190','清酒/果酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('200','190','进口起泡酒','mold','zh-cn');
INSERT INTO `jkd_category` VALUES ('201','0','123','u_group','zh-cn');


# 数据库表：jkd_field 数据信息


# 数据库表：jkd_images 数据信息
INSERT INTO `jkd_images` VALUES ('91','product','20141022085257_78359.jpg','/Uploads/image/product/20141022/20141022085257_78359.jpg','1413967979');
INSERT INTO `jkd_images` VALUES ('58','product','20141015023802_47974.jpg','/Uploads/image/product/20141015/20141015023802_47974.jpg','1413453212');
INSERT INTO `jkd_images` VALUES ('61','product','20141016095331_26721.jpg','/Uploads/image/product/20141016/20141016095331_26721.jpg','1413453260');
INSERT INTO `jkd_images` VALUES ('68','product','20141017005113_61135.jpg','/Uploads/image/product/20141017/20141017005113_61135.jpg','1413507085');
INSERT INTO `jkd_images` VALUES ('66','product','20141016095419_55266.jpg','/Uploads/image/product/20141016/20141016095419_55266.jpg','1413453792');
INSERT INTO `jkd_images` VALUES ('80','product','20141016152824_99005.jpg','/Uploads/image/product/20141016/20141016152824_99005.jpg','1413507102');
INSERT INTO `jkd_images` VALUES ('70','product','20141016152824_99005.jpg','/Uploads/image/product/20141016/20141016152824_99005.jpg','1413507085');
INSERT INTO `jkd_images` VALUES ('79','product','20141017005113_61135.jpg','/Uploads/image/product/20141017/20141017005113_61135.jpg','1413507102');
INSERT INTO `jkd_images` VALUES ('72','product','20141017005113_61135.jpg','/Uploads/image/product/20141017/20141017005113_61135.jpg','1413507085');
INSERT INTO `jkd_images` VALUES ('74','product','20141017005113_61135.jpg','/Uploads/image/product/20141017/20141017005113_61135.jpg','1413507090');
INSERT INTO `jkd_images` VALUES ('78','product','20141017005113_61135.jpg','/Uploads/image/product/20141017/20141017005113_61135.jpg','1413507102');
INSERT INTO `jkd_images` VALUES ('86','product','20141016152824_99005.jpg','/Uploads/image/product/20141016/20141016152824_99005.jpg','1413507108');
INSERT INTO `jkd_images` VALUES ('108','product','20141025080214_11554.jpg','/Uploads/image/product/20141025/20141025080214_11554.jpg','1414545794');
INSERT INTO `jkd_images` VALUES ('84','product','20141017005113_61135.jpg','/Uploads/image/product/20141017/20141017005113_61135.jpg','1413507108');
INSERT INTO `jkd_images` VALUES ('87','product','20141016152824_99005.jpg','/Uploads/image/product/20141016/20141016152824_99005.jpg','1413507108');
INSERT INTO `jkd_images` VALUES ('110','product','20141022085257_78359.jpg','/Uploads/image/product/20141022/20141022085257_78359.jpg','1414545794');
INSERT INTO `jkd_images` VALUES ('89','product','20141017005113_61135.jpg','/Uploads/image/product/20141017/20141017005113_61135.jpg','1413507108');
INSERT INTO `jkd_images` VALUES ('109','product','20141025080221_24916.jpg','/Uploads/image/product/20141025/20141025080221_24916.jpg','1414545794');
INSERT INTO `jkd_images` VALUES ('107','product','20141022085257_78359.jpg','/Uploads/image/product/20141022/20141022085257_78359.jpg','1414484603');
INSERT INTO `jkd_images` VALUES ('106','product','20141025080214_11554.jpg','/Uploads/image/product/20141025/20141025080214_11554.jpg','1414484603');


# 数据库表：jkd_input 数据信息


# 数据库表：jkd_link 数据信息


# 数据库表：jkd_member 数据信息
INSERT INTO `jkd_member` VALUES ('1','花花花啊啊','','188802862@qq.com','BoosIsMe','e8954dc6820fdfd09865b75742676881','','','2014','1','0','','bf9aa6eaf39b82e37f58575dd63ff079','/Uploads/avatar/php_source_20141022014844_133_TDN8O14Z.jpg','/Uploads/avatar/php_avatar1_20141022014844_136_MXOFXXFX.jpg','0','2','0','','0','2','6,22,23,24,25,26,28,29,31','4898998','','','','','127.0.0.1','1415061482','1414983394','127.0.0.1','/Uploads/avatar/php_avatar1_20141022014844_135_ADUJBWJD.jpg','/Uploads/avatar/php_avatar1_20141022014844_134_JDTXL3OM.jpg');
INSERT INTO `jkd_member` VALUES ('2','','','service@souzl.com','JFW_201410160250471','e8954dc6820fdfd09865b75742676881','','','','','','','471786595e3e7565a2ea415f7083059f','','','','','','','','','','','','','','','','','','','','');
INSERT INTO `jkd_member` VALUES ('3','','','huakaiquan@qq.com','JFW_201410160300348','e8954dc6820fdfd09865b75742676881','1413442834','127.0.0.1','','','','','','','','','','','','','','','','','','','','','','','','','');
INSERT INTO `jkd_member` VALUES ('4','','','416845137@qq.com','JFW_201410290337445','5cda8586719472558e5c1742071dd43e','1414568264','192.168.11.102','','','','','','','','','','','','','','','','','','','','192.168.11.102','1414568280','','','','');


# 数据库表：jkd_member_address 数据信息
INSERT INTO `jkd_member_address` VALUES ('14','黑龙江省','齐齐哈尔市','龙沙区','230961','其齐齐哈尔市','灰灰','18516222242','0','1');
INSERT INTO `jkd_member_address` VALUES ('8','山东省','聊城市','东昌府区','123456','花花哈哈哈哈','花花','18516222423','0','1');
INSERT INTO `jkd_member_address` VALUES ('13','上海市','上海市','嘉定区','200000','嘉乐园大厦2222号1106','宝宝','18516222423','1','1');


# 数据库表：jkd_message 数据信息


# 数据库表：jkd_model 数据信息
INSERT INTO `jkd_model` VALUES ('5','联系我们','jkd_about','公司信息','0','1','MyISAM','','1410592950','1410592950');
INSERT INTO `jkd_model` VALUES ('6','预订信息','jkd_order','预订信息','1','1','MyISAM','','1410850898','1410850898');


# 数据库表：jkd_nav 数据信息
INSERT INTO `jkd_nav` VALUES ('1','product','白酒','0','1','top','/jiufuwang/index.php/product/index/cid/1','zh-cn','1','Shoplist1','0','酒富网白酒','酒富网白酒','酒富网白酒');
INSERT INTO `jkd_nav` VALUES ('2','product','黄酒','0','23','top','/jiufuwang/index.php/product/index/cid/23','zh-cn','2','Shoplist2','0','酒富网黄酒','酒富网黄酒','酒富网黄酒');
INSERT INTO `jkd_nav` VALUES ('3','product','红酒','0','24','top','/jiufuwang/index.php/product/index/cid/24','zh-cn','3','Shoplist3','0','酒富网红酒','酒富网红酒','酒富网红酒');
INSERT INTO `jkd_nav` VALUES ('4','product','洋酒','0','25','top','/jiufuwang/index.php/product/index/cid/25','zh-cn','4','Shoplist4','0','酒富网洋酒','酒富网洋酒','酒富网洋酒');
INSERT INTO `jkd_nav` VALUES ('5','product','其他酒类','0','26','top','/jiufuwang/index.php/product/index/cid/26','zh-cn','5','Shoplist5','0','酒富网','酒富网','酒富网');


# 数据库表：jkd_news 数据信息


# 数据库表：jkd_node 数据信息
INSERT INTO `jkd_node` VALUES ('1','Admin','后台管理','1','网站后台管理项目','10','0','1');
INSERT INTO `jkd_node` VALUES ('2','Index','管理首页','1','','1','1','2');
INSERT INTO `jkd_node` VALUES ('3','Member','注册会员管理','1','','3','1','2');
INSERT INTO `jkd_node` VALUES ('4','Webinfo','系统管理','1','','4','1','2');
INSERT INTO `jkd_node` VALUES ('5','index','默认页','1','','5','2','3');
INSERT INTO `jkd_node` VALUES ('6','myInfo','我的个人信息','1','','6','2','3');
INSERT INTO `jkd_node` VALUES ('7','index','会员首页','1','','7','3','3');
INSERT INTO `jkd_node` VALUES ('8','index','管理员列表','1','','8','14','3');
INSERT INTO `jkd_node` VALUES ('9','addAdmin','添加管理员','1','','9','14','3');
INSERT INTO `jkd_node` VALUES ('10','index','系统设置首页','1','','10','4','3');
INSERT INTO `jkd_node` VALUES ('11','setEmailConfig','设置系统邮件','1','','12','4','3');
INSERT INTO `jkd_node` VALUES ('12','testEmailConfig','发送测试邮件','1','','0','4','3');
INSERT INTO `jkd_node` VALUES ('13','setSafeConfig','系统安全设置','1','','0','4','3');
INSERT INTO `jkd_node` VALUES ('14','Access','权限管理','1','权限管理，为系统后台管理员设置不同的权限','0','1','2');
INSERT INTO `jkd_node` VALUES ('15','nodeList','查看节点','1','节点列表信息','0','14','3');
INSERT INTO `jkd_node` VALUES ('16','roleList','角色列表查看','1','角色列表查看','0','14','3');
INSERT INTO `jkd_node` VALUES ('17','addRole','添加角色','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('18','editRole','编辑角色','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('19','opNodeStatus','便捷开启禁用节点','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('20','opRoleStatus','便捷开启禁用角色','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('21','editNode','编辑节点','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('22','addNode','添加节点','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('23','addAdmin','添加管理员','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('24','editAdmin','编辑管理员信息','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('25','changeRole','权限分配','1','','0','14','3');
INSERT INTO `jkd_node` VALUES ('26','News','资讯管理','1','','0','1','2');
INSERT INTO `jkd_node` VALUES ('27','index','新闻列表','1','','0','26','3');
INSERT INTO `jkd_node` VALUES ('28','category','新闻分类管理','1','','0','26','3');
INSERT INTO `jkd_node` VALUES ('29','add','发布新闻','1','','0','26','3');
INSERT INTO `jkd_node` VALUES ('30','edit','编辑新闻','1','','0','26','3');
INSERT INTO `jkd_node` VALUES ('31','del','删除信息','0','','0','26','3');
INSERT INTO `jkd_node` VALUES ('32','SysData','数据库管理','1','包含数据库备份、还原、打包等','0','1','2');
INSERT INTO `jkd_node` VALUES ('33','index','查看数据库表结构信息','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('34','backup','备份数据库','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('35','restore','查看已备份SQL文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('36','restoreData','执行数据库还原操作','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('37','delSqlFiles','删除SQL文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('38','sendSql','邮件发送SQL文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('39','zipSql','打包SQL文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('40','zipList','查看已打包SQL文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('41','unzipSqlfile','解压缩ZIP文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('42','delZipFiles','删除zip压缩文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('43','downFile','下载备份的SQL,ZIP文件','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('44','repair','数据库优化修复','1','','0','32','3');
INSERT INTO `jkd_node` VALUES ('46','Siteinfo','网站功能','1','','0','1','2');
INSERT INTO `jkd_node` VALUES ('47','index','菜单列表','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('48','add_nav','添加/编辑菜单','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('49','adindex','轮播列表','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('50','add_ad','添加/编辑轮播','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('51','page','单页列表','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('52','add_page','添加/编辑单页','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('53','tag_index','标签列表','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('54','add_tag','添加/编辑标签','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('55','create_tag','模版标签生成','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('56','file_index','文件管理','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('57','link_index','友情链接列表','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('58','add_link','添加/编辑友情链接','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('59','message','留言信息列表','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('60','Product','产品管理','1','','0','1','2');
INSERT INTO `jkd_node` VALUES ('61','delpage','删除单页','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('62','delad','删除轮播','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('63','dellink','删除友情链接','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('64','delmessage','删除留言','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('65','deltag','删除标签','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('66','selectCat','文章分类','1','','0','46','3');
INSERT INTO `jkd_node` VALUES ('67','index','产品列表','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('68','edit','编辑产品','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('69','add','添加产品','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('70','category','分类列表','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('71','del','删除产品','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('72','changeAttr','快速推荐','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('73','changeStatus','快速审核','0','','0','60','3');
INSERT INTO `jkd_node` VALUES ('74','changePhoneStatus','手机推荐','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('75','checkProductTitle','标题检查','1','','0','60','3');
INSERT INTO `jkd_node` VALUES ('76','changeAttr','快速推荐','1','','0','26','3');
INSERT INTO `jkd_node` VALUES ('77','changeStatus','快速审核','1','','0','26','3');
INSERT INTO `jkd_node` VALUES ('78','Models','模型管理','1','','0','1','2');
INSERT INTO `jkd_node` VALUES ('79','index','模型列表','1','','0','78','3');
INSERT INTO `jkd_node` VALUES ('80','add','添加模型','1','','0','78','3');


# 数据库表：jkd_page 数据信息


# 数据库表：jkd_product 数据信息
INSERT INTO `jkd_product` VALUES ('1','1','国人的首选','3','贵州正宗茅台酒','110.00','108,109,110','','','1','','1414223115','1414545794','<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_87088.jpg" alt="" />
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_68595.jpg" alt="" />
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_16064.jpg" alt="" />
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_77387.jpg" alt="" />
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_29931.jpg" alt="" />
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_77582.jpg" alt="" />
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_10538.jpg" alt="" />
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141029/20141029012257_55700.jpg" alt="" />
</p>','zh-cn','1','825','0','0','1','1','1','0','120.00','JFW2014102515451555',',54 ,49 ,44 ,37 ,32 ,2 ,',',43,42,47,53,58,57,56,55,30,29,36,35,','500','','0');
INSERT INTO `jkd_product` VALUES ('2','1','哇大娃娃','3','正在做这种重中之重','0.00','106,107','','','1','','1414224564','1414484603','','zh-cn','1','861','0','0','0','0','0','0','0.00','JFW2014102516092455',',54 ,49 ,',',57,56,55,53,52,51,','10','','0');
INSERT INTO `jkd_product` VALUES ('3','1','超级棒','3','超级赛亚人！！！！！！','21525.12','','','挖的挖的挖的挖阿德的瓦','0','产地：江苏<br />
香型：浓香型<br />
品牌：五粮液','1414400658','1414722971','<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_16506.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_87975.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_97294.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_87926.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_94718.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_71831.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_55991.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_15575.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_24455.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_12186.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_17835.jpg" alt="" /> 
</p>
<p style="text-align:center;">
	<img src="/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141027/20141027092546_47249.jpg" alt="" /> 
</p>','zh-cn','1','47','0','0','1','0','0','12','999525.12','JFW2014102717041846',',44 ,37 ,',',47,43,42,','4151','','0');
INSERT INTO `jkd_product` VALUES ('6','1','','3','陈坛老窖珍坛酒45度 500ml','160.00','95','泸州老窖,陈坛老窖,浓香型白酒,婚庆喜宴','泸州老窖陈坛老窖珍坛酒45度 浓香型白酒 ','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：45%Vol；','1414201754','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094900_48364.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094900_42481.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094900_63110.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094901_69762.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094901_26561.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094901_26531.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094902_30390.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094902_96965.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094903_23216.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094903_16484.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094904_40750.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094904_72635.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025094905_12927.jpg" />','zh-cn','1','0','0','0','0','0','0','0','360.00','JFW2014102509491413',',54 ,44 ,37 ,32 ,2 ,',',59,45,38,35,21,','500','','0');
INSERT INTO `jkd_product` VALUES ('7','1','','3','陈坛老窖珍坛酒52度 500ml*2','79.00','96','泸州老窖,陈坛老窖,浓香型白酒,商务宴请,高度白酒','泸州老窖陈坛老窖珍坛酒52度 500ml*2 浓香型白酒 商务宴请','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：52%Vol；','1414202028','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095336_11150.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095337_38440.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095337_18876.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095337_26045.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095338_66494.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095338_12894.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095338_24762.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095339_90991.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095339_80057.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095339_68216.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095340_74448.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095340_59658.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095340_11650.jpg" />','zh-cn','1','1','0','0','0','0','0','0','368.00','JFW2014102509534839',',54 ,44 ,37 ,32 ,2 ,',',59,45,38,36,21,','500','','0');
INSERT INTO `jkd_product` VALUES ('17','1','','3','陈坛老窖悦坛酒 38度 500ml','78.00','94','泸州老窖,陈坛老窖,浓香型白酒,礼盒白酒,婚庆喜宴，','泸州老窖陈坛老窖悦坛酒52度 500ml 礼盒酒','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：38%Vol；','1414201281','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093534_38061.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093535_78524.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093535_41239.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093536_16929.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093536_31838.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093536_96912.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093536_73031.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093537_30017.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093537_77019.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093537_91359.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093538_83627.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093538_15723.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025093538_69793.jpg" />','zh-cn','1','8','0','1','0','0','0','0','168.00','JFW2014102509412167',',54 ,44 ,37 ,32 ,2 ,',',38,45,59,34,21,','500','','0');
INSERT INTO `jkd_product` VALUES ('4','1','','3','陈坛老窖悦坛酒 52度 500ml','88.00','','泸州老窖,陈坛老窖,浓香型白酒；高度白酒；商务宴请','泸州老窖陈坛老窖52度 500ml 浓香型白酒 礼盒白酒 ','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：52%Vol；','1414201364','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092555_97286.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092555_23713.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092555_63541.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092556_12496.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092556_68743.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092556_39009.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092556_44032.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092557_42398.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092557_82237.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092557_85116.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092558_75618.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092558_13301.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025092559_23298.jpg" />','zh-cn','1','0','0','1','0','0','0','0','168.00','JFW2014102509262620',',37 ,32 ,2 ,',',38,21,36,','500','','0');
INSERT INTO `jkd_product` VALUES ('5','1','','3','陈坛老窖福坛酒 52度 500ml*2','119.00','','泸州老窖,陈坛老窖,浓香型白酒,四川名酒','泸州老窖陈坛老窖福坛酒52度 500ml*2 浓香型白酒 ','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：52%Vol；','1414201434','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091952_18434.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091953_96487.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091953_98450.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091953_75846.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091954_43760.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091954_83182.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091954_35243.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091955_74390.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091955_73229.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091956_82537.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091956_59386.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091956_43843.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025091957_83902.jpg" />','zh-cn','1','1','0','0','0','0','0','0','276.00','JFW2014102509200555',',37 ,32 ,2 ,',',38,21,36,','500','','0');
INSERT INTO `jkd_product` VALUES ('8','1','','3','陈坛老窖尚坛酒60度 2500ml','990.00','97','泸州老窖,好酒收藏,陈坛老窖,高度白酒,浓香型白酒,礼品酒','泸州老窖陈坛老窖尚坛酒 2500ml 收藏酒 浓香白酒 高度白酒 礼品酒 ','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：60%Vol；','1414202304','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095816_97407.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095816_34032.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095816_98794.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095817_19511.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095817_46073.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095817_63742.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095817_19481.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095818_24556.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095818_56271.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095818_60174.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095819_72481.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095819_47982.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025095820_48215.jpg" />','zh-cn','1','26','0','0','0','0','0','0','2980.00','JFW2014102509582430',',54 ,44 ,37 ,32 ,2 ,',',59,45,38,36,27,','500','','0');
INSERT INTO `jkd_product` VALUES ('9','1','','3','陈坛老窖八年酒52度 500ml*2','119.00','98','泸州老窖,陈坛老窖,浓香型白酒,婚宴喜庆','泸州老窖陈坛老窖八年酒 52度 500ml*2 浓香型白酒','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：52%Vol；','1414202555','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100222_25746.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100222_96830.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100222_99456.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100223_70641.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100223_15567.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100223_39025.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100224_46477.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100224_69782.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100225_29017.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100225_38737.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100225_49218.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100226_22623.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100226_16448.jpg" />','zh-cn','1','7','0','0','0','0','0','0','336.00','JFW2014102510023548',',54 ,44 ,37 ,32 ,2 ,',',59,38,36,21,','500','','0');
INSERT INTO `jkd_product` VALUES ('10','1','','3','五粮液锦绣前程荣誉酒52度 500ml*2','138.00','','五粮液,锦绣前程,礼盒酒,浓香型白酒,高度白酒','五粮液锦绣前程荣誉酒 52度 500ml*2  浓香型白酒 礼盒装','1','品牌：五粮液；产地：宜宾；生产厂家：四川宜宾五粮液股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml;度数：52%Vol；','1414202969','1414207040','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100915_99445.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100916_11263.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100916_64994.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100916_85945.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100917_54747.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100917_29745.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100917_17849.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100918_52964.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100918_87849.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100918_80710.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100918_43722.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100919_21225.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025100919_53868.jpg" />','zh-cn','1','1','0','0','0','0','0','0','298.00','JFW2014102510092964',',54 ,44 ,37 ,32 ,2 ,',',59,45,36,21,38,','500','','0');
INSERT INTO `jkd_product` VALUES ('11','1','','4','陈坛老窖六年酒52度 500ml*6','349.00','100','泸州老窖,陈坛老窖,整箱白酒,特价白酒,浓香型白酒,白酒','泸州老窖陈坛老窖酒52度 浓香型白酒 整箱包邮','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：3000ml;度数：52%Vol；','1414205099','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104448_56612.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104448_34235.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104449_57922.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104449_91455.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104449_81194.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104450_86863.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104450_84328.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104451_28912.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104451_33637.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104452_37221.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104452_87442.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104452_19527.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025104453_49482.jpg" />','zh-cn','1','4','0','0','0','0','0','0','708.00','JFW2014102510445911',',54 ,44 ,37 ,32 ,2 ,',',59,45,38,36,21,','300','','0');
INSERT INTO `jkd_product` VALUES ('12','1','','4','陈坛老窖八年酒52度 500ml*6','359.00','101','泸州老窖,陈坛老窖,浓香型白酒,整箱包邮','泸州老窖陈坛老窖52度 500ml*6 整箱包邮','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml*6;度数：52%Vol；','1414205510','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105140_96363.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105140_15712.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105141_81611.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105141_40668.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105141_24405.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105142_82067.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105142_14427.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105143_14627.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105143_80076.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105143_85660.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105144_51638.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105144_93718.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105145_21574.jpg" />','zh-cn','1','3','0','0','0','0','0','0','1008.00','JFW2014102510515089',',54 ,44 ,37 ,32 ,2 ,',',59,45,38,36,21,','300','','0');
INSERT INTO `jkd_product` VALUES ('13','1','','4','陈坛老窖福坛酒52度 500ml*6','269.00','102','泸州老窖,陈坛老窖,整箱包邮,浓香型白酒','泸州老窖陈坛老窖酒52度 500ml*6 整箱包邮 浓香型白酒','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml*6;度数：52%Vol；','1414205899','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105808_35661.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105808_99082.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105808_76101.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105809_33554.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105809_91367.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105809_69057.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105810_71432.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105810_70238.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105810_22977.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105811_45183.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105811_17369.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105812_32917.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025105812_78161.jpg" />','zh-cn','1','2','0','0','0','0','0','0','708.00','JFW2014102510581963',',54 ,44 ,37 ,32 ,2 ,',',59,45,38,36,21,','300','','0');
INSERT INTO `jkd_product` VALUES ('14','1','','4','五粮液锦绣前程荣升酒52度 500ml*6','1069.00','','五粮液,锦绣前程,整箱包邮,整箱特价,浓香型白酒,四川白酒','五粮液锦绣前程荣升酒 52度 500ml*6 整箱包邮 浓香型白酒','1','品牌：五粮液；产地：四川宜宾；生产厂家：四川宜宾五粮液股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml*6;度数：52%Vol；','1414206834','1414207066','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111255_28558.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111256_97149.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111256_45340.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111257_10527.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111257_11387.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111257_81185.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111258_94929.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111258_43483.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111258_46018.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111259_40879.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111259_83773.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111300_39693.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025111300_98088.jpg" />','zh-cn','1','16','0','0','0','0','0','0','2328.00','JFW2014102511135426',',54 ,44 ,37 ,32 ,2 ,',',55,38,28,27,22,','200','','0');
INSERT INTO `jkd_product` VALUES ('15','1','','4','陈坛老窖珍坛酒52度 500ml*6','469.00','104','泸州老窖,陈坛老窖,整箱包邮,特价白酒,商务宴请','泸州老窖陈坛老窖酒52度 500ml*6 整箱包邮 浓香型白酒','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml*6;度数：52%Vol；','1414207371','','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112241_62846.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112242_22810.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112242_42821.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112242_11452.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112243_24279.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112243_54620.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112243_39154.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112243_28204.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112244_42555.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112244_75396.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112245_81770.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112245_88969.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025112245_79106.jpg" />','zh-cn','1','100','0','0','0','0','0','0','2208.00','JFW2014102511225157',',54 ,44 ,37 ,32 ,2 ,',',59,45,38,36,22,21,','300','','0');
INSERT INTO `jkd_product` VALUES ('16','1','','4','陈坛老窖悦坛酒52度 500ml*6','469.00','','泸州老窖,陈坛老窖,浓香型白酒,整箱包邮','泸州老窖陈坛老窖酒52度 500ml*6 浓香型白酒 整箱包邮 特价','1','品牌：泸州老窖；产地：泸州；生产厂家：泸州老窖股份有限公司；配料：水、高粱、小麦；香型：浓香型；净含量：500ml*6;度数：52%Vol；','1414208503','1414208537','<img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114133_44810.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114133_18157.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114134_18995.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114134_97648.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114134_91389.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114135_68650.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114135_77903.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114135_60202.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114136_39989.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114136_27446.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114137_10249.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114137_51715.jpg" /><img alt="" src="/huahua/jiufuwang/Public/kindeditor/php/../../../Uploads/image/product/20141025/20141025114137_33052.jpg" />','zh-cn','1','34','0','0','0','0','0','0','1008.00','JFW2014102511414391',',54 ,44 ,37 ,32 ,2 ,',',59,45,36,38,22,21,','200','','0');


# 数据库表：jkd_product_ask 数据信息
INSERT INTO `jkd_product_ask` VALUES ('9','','1','商品提问','0','北京北三环现在下单，晚上下班前能到否？','1414205565','1414205565','');
INSERT INTO `jkd_product_ask` VALUES ('10','','1','商品提问','0','到杭州17号能不能到货','1414205714','1414205714','');
INSERT INTO `jkd_product_ask` VALUES ('11','','1','商品提问','0','到杭州17号能不能到货','1414205724','1414205724','');
INSERT INTO `jkd_product_ask` VALUES ('12','','1','商品提问','0','到杭州17号能不能到货','1414205787','1414205787','');
INSERT INTO `jkd_product_ask` VALUES ('13','1232','1','商品提问','0','购买后能发到河北省蠡县县城吗','1414217801','1414218510','');
INSERT INTO `jkd_product_ask` VALUES ('14','1232','1','促销活动提问','0','请问下是发什么快递呢 ？单号JX8576636','1414217946','1414218504','');
INSERT INTO `jkd_product_ask` VALUES ('15','1232','1','库存及物流提问','1','加价购怎么操作','1414217970','1414219054','亲爱的会员，我看到您的订单已经发货成功，订单号是【门对门】【JX8576636】，请您耐心等待，美酒很快就到家了。嘿嘿，感谢您对酒富网的支持，祝您每天都有一个好心情。');


# 数据库表：jkd_product_cart 数据信息


# 数据库表：jkd_product_collect 数据信息
INSERT INTO `jkd_product_collect` VALUES ('8','15','1','1414722262','1414722262');
INSERT INTO `jkd_product_collect` VALUES ('9','3','1','1414723513','1414723513');
INSERT INTO `jkd_product_collect` VALUES ('10','16','1','1414803709','1414803709');


# 数据库表：jkd_product_comment 数据信息


# 数据库表：jkd_product_order 数据信息
INSERT INTO `jkd_product_order` VALUES ('2','JFW2014110317430257','1','138,135,134,128,129,127,109','13','不限时间','不开具发票','21357.00','0','无礼品','0','0','','127.0.0.1','1415007782','1415007782');
INSERT INTO `jkd_product_order` VALUES ('3','JFW2014110317453083','1','138,135,134,128,129,127,109','13','不限时间','不开具发票','21357.00','0','无礼品','0','2','','127.0.0.1','1415007930','1415007930');
INSERT INTO `jkd_product_order` VALUES ('4','JFW2014110317460991','1','138,135,134,128,129,127,109','13','不限时间','不开具发票','21357.00','0','无礼品','0','3','','127.0.0.1','1415007969','1415007969');
INSERT INTO `jkd_product_order` VALUES ('5','JFW2014110317465094','1','138,135,134,128,129,127,109','13','不限时间','不开具发票','21357.00','0','无礼品','0','4','','127.0.0.1','1415008010','1415008010');
INSERT INTO `jkd_product_order` VALUES ('6','JFW2014110408590693','1','140,139','13','不限时间','不开具发票','1538.00','0','无礼品','0','1','','127.0.0.1','1415062746','1415062746');
INSERT INTO `jkd_product_order` VALUES ('7','JFW2014110409245870','1','142,141','8','不限时间','不开具发票','607.00','0','无礼品','0','6','','127.0.0.1','1415064298','1415064298');
INSERT INTO `jkd_product_order` VALUES ('8','JFW2014110409251889','1','143','8','不限时间','不开具发票','469.00','0','无礼品','0','7','','127.0.0.1','1415064318','1415064318');
INSERT INTO `jkd_product_order` VALUES ('9','JFW2014110409304595','1','144','8','不限时间','不开具发票','469.00','0','无礼品','0','5','','127.0.0.1','1415064645','1415064645');


# 数据库表：jkd_role 数据信息
INSERT INTO `jkd_role` VALUES ('1','超级管理员','0','1','系统内置超级管理员组，不受权限分配账号限制');
INSERT INTO `jkd_role` VALUES ('2','管理员','1','1','拥有系统仅此于超级管理员的权限');
INSERT INTO `jkd_role` VALUES ('3','领导','1','1','拥有所有操作的读权限，无增加、删除、修改的权限');
INSERT INTO `jkd_role` VALUES ('4','测试组','1','1','测试');


# 数据库表：jkd_role_user 数据信息
INSERT INTO `jkd_role_user` VALUES ('3','4');


# 数据库表：jkd_tag 数据信息
